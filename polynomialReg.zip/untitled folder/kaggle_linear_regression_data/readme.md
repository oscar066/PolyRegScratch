The dataset has been taken from [Kaggle](https://www.kaggle.com/andonians/random-linear-regression).
